# 如何把这个项目变成 APK（云端构建 · 全程不用装开发软件）

> 思路：你的电脑/沙箱里无法直接编译 APK，但 GitHub 提供免费的云端构建。
> 你只要把这个项目上传到 GitHub，它会自动编译出一个可安装的 `app-debug.apk`，你下载下来装到售货机即可。
> 全程约 10 分钟，不需要安装 Android Studio 或任何开发工具。

---

## 准备：一个 GitHub 账号（免费）

打开 https://github.com ，注册并登录。

---

## 第 1 步：新建一个仓库（repository）

1. 登录后，点右上角 **「＋」→ New repository**。
2. **Repository name** 随便填，例如 `checklist-app`。
3. 选 **Public** 或 **Private** 都行。
4. **不要**勾选 “Add a README”。
5. 点 **Create repository**。

---

## 第 2 步：上传项目文件

1. 先把我给你的 **`checklist-app.zip` 解压**，得到 `checklist-app` 文件夹。
2. 在刚建好的空仓库页面，点 **「uploading an existing file」**（或 **Add file → Upload files**）。
3. 打开解压后的 `checklist-app` 文件夹，**把里面的所有内容全选**（注意：是文件夹**里面**的东西，不是外层的 `checklist-app` 文件夹本身），**拖进网页的上传区**。
4. 等待上传完成，下方填一句说明（可留空），点 **Commit changes**。

> ⚠️ 如果上传后发现 **`.github` 文件夹没传上去**（有些浏览器会忽略以点开头的文件夹），不要紧，手动补一个：
> - 点 **Add file → Create new file**
> - 文件名框里输入：`.github/workflows/build-apk.yml`（输入 `/` 会自动建出文件夹）
> - 把本指南最后【附录】里的内容**整段粘贴**进去
> - 点 **Commit changes**

---

## 第 3 步：等待云端自动编译

1. 上传完成后，构建通常会**自动开始**。
2. 点仓库顶部的 **「Actions」** 标签，会看到一条名为 **“Build APK”** 的记录：
   - 🟡 黄色 = 正在编译（约 2–4 分钟）
   - ✅ 绿色 = 成功
   - ❌ 红色 = 失败（点进去看日志，多数情况重试一次即可）
3. 如果没有自动开始：进 **Actions → 左侧点 “Build APK” → 右侧 “Run workflow” → Run workflow**。

---

## 第 4 步：下载 APK

1. 点开那条 ✅ 绿色的运行记录。
2. 滑到页面最下方 **「Artifacts」** 区域。
3. 点 **`checklist-apk`** 下载（下载下来是个 zip）。
4. 解压它，里面就是 **`app-debug.apk`**。

---

## 第 5 步：装到售货机

1. 把 `app-debug.apk` 传到售货机（U 盘、网络下载、或文件传输都行）。
2. 在售货机的 Android 设置里，**允许“未知来源 / 安装未知应用”**。
3. 点击 `app-debug.apk` → 安装 → 打开。
4. 打开后是全屏的待办清单：点 **「＋ 添加任务」** 添加每日 / 每周事项，点事项前的圆圈打勾，点 **「重置」** 清除勾选。数据存在本机，**断电不丢**。

> 说明：这是 **debug 签名** 的安装包。用于自家设备旁加载（sideload）完全没问题；它不能上架应用商店，但你的场景用不到上架。

---

## 常见问题

**Q：构建失败（红色）怎么办？**
点开失败的运行 → 看红色那一步的日志。多数是临时网络波动，回到 Actions 点 **Run workflow** 重试一次即可。

**Q：售货机装不上 / 提示“解析包错误”？**
通常是系统太旧。本应用最低支持 Android 5.0。若仍不行，告诉我你的安卓版本，我再调。

**Q：想让它开机自启 / 锁定为唯一界面（防顾客退出）？**
可以，需要把它设为系统启动器或配合锁屏方案，告诉我你的售货机系统，我给你具体做法。

---

## 【附录】build-apk.yml 全文（手动补文件时用）

```yaml
name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Set up Gradle 8.7
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'

      - name: Build debug APK
        run: gradle assembleDebug --no-daemon --stacktrace

      - name: Upload APK artifact
        uses: actions/upload-artifact@v4
        with:
          name: checklist-apk
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```
