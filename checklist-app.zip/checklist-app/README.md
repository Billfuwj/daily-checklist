# 待办清单（每日 / 每周）Android 应用

一个全屏、离线、适合售货机触摸屏的「每日 / 每周必办事项」清单 App。

## 功能
- 「每日」「每周」两个清单，**空白模板**：在设备上自行添加 / 编辑 / 删除事项。
- 点事项前的圆圈打勾完成；**手动重置**（点「重置」清除当前清单的所有勾选，事项保留）。
- 数据保存在本机（localStorage），**断电 / 重启不丢**。
- 全屏沉浸式、屏幕常亮、大号触控按钮，中文界面。
- **完全离线**，不申请网络权限。

## 我该怎么得到 APK？
请看 **《如何获取APK_操作指南.md》** —— 用 GitHub 免费云端构建，全程不用安装任何开发工具，约 10 分钟拿到可安装的 `app-debug.apk`。

## 想现在就预览界面？
直接用手机或电脑浏览器打开根目录的 **`预览_index.html`** 即可体验全部交互（添加 / 勾选 / 重置 / 持久保存）。这跟装进 App 里的是同一套界面。

## 给开发者：本地编译
需要 JDK 17 + Android SDK（platform 34、build-tools 34）。
```bash
# 在项目根目录，新建 local.properties 指向你的 SDK：
echo "sdk.dir=/path/to/Android/sdk" > local.properties

gradle assembleDebug          # 或 ./gradlew assembleDebug（若已生成 wrapper）
# 产物： app/build/outputs/apk/debug/app-debug.apk
```

## 技术构成
- 极薄的原生外壳 `MainActivity.java`：一个全屏 `WebView` 加载 `assets/index.html`，开启 DOM storage、屏幕常亮、沉浸全屏、拦截返回键（防顾客误退出）。
- 全部清单逻辑在 `app/src/main/assets/index.html`（纯 HTML/CSS/JS，ES5 写法以兼容老旧 WebView）。
- 无 AndroidX、无三方依赖 —— 构建快、出错点少。

## 目录结构
```
checklist-app/
├─ settings.gradle / build.gradle / gradle.properties
├─ app/
│  ├─ build.gradle
│  └─ src/main/
│     ├─ AndroidManifest.xml
│     ├─ assets/index.html          ← 应用界面与逻辑
│     ├─ java/com/dadaofu/checklist/MainActivity.java
│     └─ res/
│        ├─ drawable/ic_launcher.png
│        └─ values/strings.xml
├─ .github/workflows/build-apk.yml  ← 云端自动构建
├─ 如何获取APK_操作指南.md
└─ 预览_index.html                   ← 浏览器直接预览
```

## 自定义小贴士
- **应用名 / 图标**：改 `res/values/strings.xml` 的 `app_name`、替换 `res/drawable/ic_launcher.png`。
- **允许返回键退出**（方便调试）：把 `MainActivity.java` 的 `onBackPressed()` 改成调用 `super.onBackPressed()`。
- **包名**：当前为 `com.dadaofu.checklist`，如需修改请同步改 `applicationId`、`namespace` 与目录。
