# No special ProGuard rules needed for this app.
# The app is a thin WebView wrapper around bundled HTML assets.
