// Ad-hoc code-sign the .app so it can run on Apple Silicon (arm64 requires a
// valid signature; ad-hoc satisfies that, though the app is not notarized).
const { execSync } = require('child_process');
const path = require('path');

exports.default = async function (context) {
  if (context.electronPlatformName !== 'darwin') return;
  const appName = context.packager.appInfo.productFilename + '.app';
  const appPath = path.join(context.appOutDir, appName);
  console.log('Ad-hoc signing: ' + appPath);
  execSync('codesign --deep --force -s - "' + appPath + '"', { stdio: 'inherit' });
};
